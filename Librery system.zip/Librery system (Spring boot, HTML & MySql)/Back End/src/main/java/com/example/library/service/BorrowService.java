package com.example.library.service;

import com.example.library.model.BorrowRecord;
import com.example.library.model.Book;
import com.example.library.model.Member;
import com.example.library.repository.BorrowRepository;
import com.example.library.repository.BookRepository;
import com.example.library.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BorrowService {

    @Autowired
    private BorrowRepository borrowRepository;

    @Autowired
    private BookRepository bookRepository; // Add BookRepository for book fetching

    @Autowired
    private MemberRepository memberRepository; // Add MemberRepository for member fetching

    // Get all borrow records
    public List<BorrowRecord> getAllBorrowRecords() {
        return borrowRepository.findAll();
    }

    // Save a new borrow record
    public BorrowRecord saveBorrowRecord(BorrowRecord borrowRecord) {
        return borrowRepository.save(borrowRecord);
    }

    // Update an existing borrow record
    public BorrowRecord updateBorrowRecord(Long id, BorrowRecord updatedBorrowRecord) {
        Optional<BorrowRecord> existingRecord = borrowRepository.findById(id);
        if (existingRecord.isPresent()) {
            BorrowRecord record = existingRecord.get();

            // Fetch book and member objects based on the IDs
            Optional<Book> bookOptional = bookRepository.findById(updatedBorrowRecord.getBook().getId());
            Optional<Member> memberOptional = memberRepository.findById(updatedBorrowRecord.getMember().getId());

            if (bookOptional.isPresent() && memberOptional.isPresent()) {
                record.setBook(bookOptional.get()); // Set the actual Book entity
                record.setMember(memberOptional.get()); // Set the actual Member entity
                record.setBorrowDate(updatedBorrowRecord.getBorrowDate()); // Set the borrow date
                record.setReturnDate(updatedBorrowRecord.getReturnDate()); // Set the return date

                return borrowRepository.save(record); // Save the updated borrow record
            } else {
                throw new RuntimeException("Book or Member not found with provided ID");
            }
        } else {
            throw new RuntimeException("Borrow record not found with id: " + id);
        }
    }

    // Delete a borrow record by ID
    public void deleteBorrowRecord(Long id) {
        borrowRepository.deleteById(id);
    }
}
