package com.example.library.controller;

import com.example.library.model.BorrowRecord;
import com.example.library.service.BorrowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://127.0.0.1:5500")  // Enable CORS for this controller
@RestController
@RequestMapping("/api/borrows")
public class BorrowController {

    @Autowired
    private BorrowService borrowService;

    @GetMapping
    public List<BorrowRecord> getAllBorrowRecords() {
        return borrowService.getAllBorrowRecords();
    }

    @PostMapping
    public BorrowRecord addBorrowRecord(@RequestBody BorrowRecord borrowRecord) {
        return borrowService.saveBorrowRecord(borrowRecord);
    }

    @PutMapping("/{id}")
    public BorrowRecord updateBorrowRecord(@PathVariable Long id, @RequestBody BorrowRecord updatedBorrowRecord) {
        return borrowService.updateBorrowRecord(id, updatedBorrowRecord);
    }

    @DeleteMapping("/{id}")
    public void deleteBorrowRecord(@PathVariable Long id) {
        borrowService.deleteBorrowRecord(id);
    }
}

