package com.example.library.service;

import com.example.library.model.Member;
import com.example.library.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MemberService {

    @Autowired
    private MemberRepository memberRepository;

    public List<Member> getAllMembers() {
        return memberRepository.findAll();
    }

    public Member saveMember(Member member) {
        return memberRepository.save(member);
    }

    public Member updateMember(Long id, Member updatedMember) {
        Optional<Member> existingMember = memberRepository.findById(id);
        if (existingMember.isPresent()) {
            Member member = existingMember.get();
            member.setName(updatedMember.getName()); // Assuming Member has a "name" field
            member.setEmail(updatedMember.getEmail()); // Assuming Member has an "email" field
            return memberRepository.save(member);
        } else {
            throw new RuntimeException("Member not found with id: " + id);
        }
    }

    public void deleteMember(Long id) {
        memberRepository.deleteById(id);
    }
}
