 // Fetch all books and display them
 const getBooks = async () => {
  const response = await fetch('http://localhost:8080/api/books');
  const books = await response.json();
  const bookList = document.getElementById('bookList');
  bookList.innerHTML = ''; // Clear the table before displaying the books

  books.forEach(book => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${book.id}</td>
      <td>${book.title}</td>
      <td>${book.author}</td>
      <td>${book.copiesAvailable}</td>
      <td>
        <button class="btn btn-warning btn-sm" onclick="editBook(${book.id})">Edit</button>
        <button class="btn btn-danger btn-sm" onclick="deleteBook(${book.id})">Delete</button>
      </td>
    `;
    bookList.appendChild(row);
  });
};

// Add new book
document.getElementById('bookForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const title = document.getElementById('bookTitle').value;
  const author = document.getElementById('bookAuthor').value;
  const copies = document.getElementById('bookCopies').value;

  const response = await fetch('http://localhost:8080/api/books', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ title, author, copiesAvailable: copies }),
  });
  if (response.ok) {
    getBooks(); // Refresh the book list
    document.getElementById('bookForm').reset(); // Clear the form
  } else {
    alert('Failed to add book');
  }
});

// Edit book (populate the form with existing data)
const editBook = async (id) => {
  const response = await fetch(`http://localhost:8080/api/books/${id}`);
  const book = await response.json();

  document.getElementById('bookTitle').value = book.title;
  document.getElementById('bookAuthor').value = book.author;
  document.getElementById('bookCopies').value = book.copiesAvailable;

  // Change form action to update
  document.getElementById('bookForm').onsubmit = async (e) => {
    e.preventDefault();
    const title = document.getElementById('bookTitle').value;
    const author = document.getElementById('bookAuthor').value;
    const copies = document.getElementById('bookCopies').value;

    const response = await fetch(`http://localhost:8080/api/books/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ id, title, author, copiesAvailable: copies }),
    });
    if (response.ok) {
      getBooks(); // Refresh the book list
      document.getElementById('bookForm').reset(); // Clear the form
    } else {
      alert('Failed to update book');
    }
  };
};

// Delete book
const deleteBook = async (id) => {
  const response = await fetch(`http://localhost:8080/api/books/${id}`, {
    method: 'DELETE',
  });
  if (response.ok) {
    getBooks(); // Refresh the book list
  } else {
    alert('Failed to delete book');
  }
};

// Initialize by fetching books
getBooks();



